package SharedData;

public class LineHolder {
    int lineNumber;
    Integer[] line;
       
    public LineHolder(Integer[] l, int lineNumber){
        this.line = l;
        this.lineNumber = lineNumber;
    }
}
